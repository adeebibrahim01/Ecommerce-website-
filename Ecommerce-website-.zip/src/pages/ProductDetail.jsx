import { useState, useEffect } from "react";
import { useParams, useNavigate, useSearchParams } from "react-router-dom";
import { Heart, ShoppingBag, ArrowLeft, Minus, Plus, Check, Tag } from "lucide-react";
import { useAuth } from "../hooks/useAuth";
import { useCart } from "../hooks/useCart";
import { useWishlist } from "../hooks/useWishlist";
import { getProductPath, parseProductId } from "../utils/productUrl";

const API_BASE =
  import.meta.env.VITE_PRODUCT_API_URL || "https://product-worker-service.adeebibrahim01.workers.dev";

// Worker ka row snake_case mein hai (sale_price, filter_category,
// category_name, brand_name), yahan usko wohi shape de rahe hain jo
// neeche ka JSX expect karta hai (bilkul ProductGrid.jsx jaisa normalize).
function normalizeProduct(row) {
  return {
    id: row.id,
    name: row.name,
    price: row.sale_price ?? row.price,
    originalPrice: row.sale_price ? row.price : null,
    image: row.image,
    category: row.category_name,
    brand: row.brand_name,
    badge: row.badge,
    description: row.description,
  };
}

// ─────────────────────────────────────────────────────────────
// Skeleton — mirrors the real layout below so there's no layout
// shift once the product data arrives.
// ─────────────────────────────────────────────────────────────

function ProductDetailSkeleton() {
  return (
    <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 md:px-12 lg:px-16">
      <div className="mb-8 h-3 w-40 animate-pulse rounded-sm bg-[#D1B79E]/30" />

      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        {/* Image placeholder */}
        <div className="aspect-[3/4] animate-pulse bg-[#D1B79E]/30" />

        {/* Details placeholder */}
        <div className="flex flex-col justify-center">
          <div className="h-2.5 w-1/3 animate-pulse rounded-sm bg-[#D1B79E]/25" />
          <div className="mt-4 h-9 w-3/4 animate-pulse rounded-sm bg-[#D1B79E]/40" />

          <div className="mt-4 flex items-baseline gap-3">
            <div className="h-6 w-20 animate-pulse rounded-sm bg-[#D1B79E]/35" />
            <div className="h-4 w-14 animate-pulse rounded-sm bg-[#D1B79E]/20" />
          </div>

          <div className="my-6 h-[1px] w-full bg-[#D1B79E]/40" />

          <div className="space-y-2">
            <div className="h-2.5 w-full animate-pulse rounded-sm bg-[#D1B79E]/25" />
            <div className="h-2.5 w-full animate-pulse rounded-sm bg-[#D1B79E]/25" />
            <div className="h-2.5 w-2/3 animate-pulse rounded-sm bg-[#D1B79E]/25" />
          </div>

          <div className="mt-8 flex items-center gap-6">
            <div className="h-2.5 w-16 animate-pulse rounded-sm bg-[#D1B79E]/30" />
            <div className="h-10 w-28 animate-pulse rounded-sm bg-[#D1B79E]/25" />
          </div>

          <div className="mt-8 flex items-center gap-4">
            <div className="h-[52px] flex-1 animate-pulse rounded-sm bg-[#D1B79E]/35" />
            <div className="h-[52px] w-[52px] shrink-0 animate-pulse rounded-sm bg-[#D1B79E]/25" />
          </div>
        </div>
      </div>
    </div>
  );
}

export default function ProductDetail() {
  const { slug } = useParams();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [searchParams] = useSearchParams();

  // The route param can be a plain old id ("5") or the new
  // professional slug ("elegant-silk-evening-dress-5") — either
  // way, the real numeric id is what we fetch and key everything by.
  const id = parseProductId(slug);

  const activeUserId = user?.id || user?._id || user?.sub || user?.email || null;

  // Same hook, same query key ("cart", activeUserId) as Navbar and CartPage —
  // so an add here is instantly visible everywhere else, no custom events needed.
  const { cartItems, addToCart, isMutating, isLoading: cartLoading } = useCart(activeUserId);

  // Same hook ProductCard uses — so a like/unlike here is instantly
  // reflected on the grid, and vice versa (shared "wishlist" query key).
  const {
    isInWishlist,
    toggleWishlist,
    removeFromWishlist,
    isMutating: isWishlistMutating,
  } = useWishlist(activeUserId);

  const [product, setProduct] = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  const [quantity, setQuantity] = useState(1);
  const [cartMessage, setCartMessage] = useState("");
  const [cartMessageTone, setCartMessageTone] = useState("neutral"); // "good" | "bad"

  // ── Deal context (optional) ─────────────────────────────────
  // Jab koi product DealDetailPage se open hota hai, us link mein
  // ?deal=<name>&dealId=<id>&dealPrice=<discountedPrice> hote hain.
  // Yahan hum unhe read karte hain taake "SHOPING SALE" jaisa badge
  // aur discounted price sahi dikhaya ja sake — bilkul DealDetailPage
  // ke ProductCard jaisa.
  const dealName = searchParams.get("deal");
  const dealId = searchParams.get("dealId");
  const dealPriceParam = searchParams.get("dealPrice");
  const hasDeal = Boolean(dealName && dealPriceParam);

  // Database se product laana hai — /products/:id koi auth nahi maangta.
  useEffect(() => {
    if (!id) {
      // Slug se koi numeric id nahi mil saka (badly formed URL).
      setLoading(false);
      setProduct(null);
      setError("Product not found.");
      return;
    }

    const controller = new AbortController();
    // `controller.signal.aborted` akela kaafi nahi hai — jab yeh effect
    // StrictMode (dev) mein double-run hota hai, pehli request abort ho
    // kar bhi apna `.finally` chalati hai, jo `loading` ko waqt se pehle
    // false kar deta tha (product abhi tak null hone ki wajah se "Product
    // not found" ek pal ke liye flash ho jata tha). `cancelled` flag har
    // stale request ke result ko UI tak pohanchne se rok deta hai.
    let cancelled = false;

    setLoading(true);
    setError(null);

    fetch(`${API_BASE}/products/${id}`, { signal: controller.signal })
      .then(async (res) => {
        const data = await res.json();
        if (!res.ok || !data?.success) {
          throw new Error(data?.message || "Product not found.");
        }
        if (cancelled) return;
        setProduct(normalizeProduct(data.product));
      })
      .catch((err) => {
        if (cancelled || err.name === "AbortError") return;
        console.error("Error loading product:", err);
        setError(err.message || "Failed to load product details.");
      })
      .finally(() => {
        if (cancelled) return;
        setLoading(false);
      });

    return () => {
      cancelled = true;
      controller.abort();
    };
  }, [id]);

  // Product load hote hi URL ko canonical, human-readable slug mein
  // "upgrade" kar dete hain (jaise YouTube apne share links ke sath
  // karta hai) — replace: true taake back button par ye extra step
  // na aaye. Agar koi already sahi slug pe hai to kuch nahi hota.
  // Deal query params ko bhi preserve karte hain taake redirect ke
  // baad badge/discount gayab na ho jaye.
  useEffect(() => {
    if (!product) return;
    const canonicalPath = getProductPath(product);
    const currentPath = `/product/${slug}`;
    if (canonicalPath !== currentPath) {
      const qs = searchParams.toString();
      navigate(qs ? `${canonicalPath}?${qs}` : canonicalPath, { replace: true });
    }
  }, [product, slug, navigate, searchParams]);

  // Reset transient UI state whenever we land on a different product.
  // Keyed off `id` (not `slug`) so the canonical-slug redirect above
  // — which changes the URL but not the product — doesn't reset the
  // quantity picker or wishlist toggle the user just set.
  useEffect(() => {
    setQuantity(1);
    setCartMessage("");
  }, [id]);

  const liked = isInWishlist(product?.id ?? id, hasDeal ? dealId : undefined);

  // How many of this product are already in the bag — purely informational.
  const existingQuantity = (cartItems || [])
    .filter((item) => {
      const sameProduct = String(item.productId || item.product_id) === String(id);
      const sameDeal = hasDeal
        ? String(item.dealId ?? item.deal_id ?? "") === String(dealId ?? "")
        : !(item.dealId ?? item.deal_id);
      return sameProduct && sameDeal;
    })
    .reduce((sum, item) => sum + Number(item.quantity || 0), 0);

  // Deal active hone par effective price/original price wahi logic
  // follow karte hain jo DealDetailPage mein hai: current price =
  // discounted deal price, original price = product ka asal price.
  const numericProductPrice =
    typeof product?.price === "number"
      ? product.price
      : parseFloat(String(product?.price).replace(/[^0-9.]/g, "")) || 0;

  const effectivePrice = hasDeal ? Number(dealPriceParam) : product?.price;
  const effectiveOriginalPrice = hasDeal ? numericProductPrice : product?.originalPrice;

  // Wishlist hamesha "original" (non-discounted) price store karti hai —
  // bilkul ProductCard ke handleToggleWishlist jaisa.
  const wishlistOriginalPrice = hasDeal
    ? numericProductPrice
    : product?.originalPrice ?? numericProductPrice;

  const handleAddToCart = async () => {
    if (!product) return;

    if (!activeUserId) {
      setCartMessageTone("bad");
      setCartMessage("Please sign in to add items to your bag.");
      setTimeout(() => navigate("/login"), 1000);
      return;
    }

    setCartMessage("");

    // `quantity` here is a delta — "how many more to add" — matching how
    // useCart's /cart/add mutation and the backend SQL treat it everywhere else.
    const ok = await addToCart(product.id, quantity, {
      name: product.name,
      price: hasDeal ? Number(dealPriceParam) : numericProductPrice,
      image: product.image || "",
      // Deal se aaya hai to wahi fields jo DealDetailPage bhejta hai —
      // taake cart/cart-dropdown mein deal badge sahi se render ho.
      ...(hasDeal && {
        dealId: dealId || undefined,
        dealName,
        originalPrice: numericProductPrice,
      }),
    });

    if (ok) {
      setCartMessageTone("good");
      setCartMessage(`Added ${quantity} to your bag.`);
      setQuantity(1);
      // Cart mein add ho gaya to wishlist se nikal do — bilkul ProductCard
      // ke Quick Add jaisa behavior.
      if (liked) {
        removeFromWishlist(product.id, hasDeal ? dealId : undefined);
      }
    } else {
      setCartMessageTone("bad");
      setCartMessage("Something went wrong adding this to your bag. Please try again.");
    }
  };

  const handleToggleWishlist = async () => {
    if (!product || isWishlistMutating) return;

    if (!activeUserId) {
      setCartMessageTone("bad");
      setCartMessage("Please sign in to use your wishlist.");
      setTimeout(() => navigate("/login"), 1000);
      return;
    }

    await toggleWishlist(product.id, {
      name: product.name,
      price: wishlistOriginalPrice,
      image: product.image,
      ...(hasDeal && { dealId: dealId || undefined, dealName }),
    });
  };

  if (loading) {
    return <ProductDetailSkeleton />;
  }

  if (error || !product) {
    return (
      <div className="flex h-[70vh] flex-col items-center justify-center gap-4">
        <p className="text-sm text-[#432817]">{error || "Product not found."}</p>
        <button
          onClick={() => navigate(-1)}
          className="flex items-center gap-2 bg-[#432817] px-6 py-3 text-[10px] tracking-[0.2em] text-[#EDE6DA] uppercase"
        >
          <ArrowLeft size={14} /> Go Back
        </button>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-5 py-12 sm:px-8 md:px-12 lg:px-16">
      <button
        onClick={() => navigate(-1)}
        className="group mb-8 flex items-center gap-2 text-[10px] font-medium tracking-[0.2em] text-[#7E7E86] uppercase transition hover:text-[#432817]"
      >
        <ArrowLeft size={14} className="transition-transform group-hover:-translate-x-1" />
        Back to collection
      </button>

      <div className="grid gap-12 lg:grid-cols-2 lg:gap-16">
        {/* Product Image */}
        <div className="relative aspect-[3/4] overflow-hidden bg-[#D1B79E]/30">
          {product.image ? (
            <img src={product.image} alt={product.name} className="h-full w-full object-cover" />
          ) : (
            <div className="flex h-full w-full items-center justify-center text-[#7E7E86]">No Image Available</div>
          )}
          {product.badge && !hasDeal && (
            <div className="absolute left-4 top-4 bg-[#EDE6DA] px-3 py-1.5">
              <span className="text-[8px] font-medium tracking-[0.15em] text-[#432817] uppercase">
                {product.badge}
              </span>
            </div>
          )}
        </div>

        {/* Product Details */}
        <div className="flex flex-col justify-center">
          {/* Deal badge — matches the dark pill used on DealDetailPage's ProductCard */}
          {hasDeal && (
            <div className="mb-3 inline-flex w-fit items-center gap-1.5 rounded-full bg-[#432817] px-3 py-1.5">
              <Tag size={11} strokeWidth={2} className="text-[#EDE6DA]" />
              <span className="text-[9px] font-semibold tracking-[0.1em] text-[#EDE6DA] uppercase">
                {dealName}
              </span>
            </div>
          )}

          {(product.category || product.brand) && (
            <p className="mb-3 text-[10px] tracking-[0.25em] text-[#7E7E86] uppercase">
              {[product.category, product.brand].filter(Boolean).join(" · ")}
            </p>
          )}

          <h1 className="font-serif text-3xl text-[#432817] sm:text-4xl">{product.name}</h1>

          <div className="mt-4 flex items-baseline gap-3">
            <p className="text-xl font-medium text-[#432817]">
              {typeof effectivePrice === "number" ? `$${effectivePrice.toLocaleString()}` : effectivePrice}
            </p>
            {effectiveOriginalPrice ? (
              <p className="text-sm text-[#7E7E86] line-through">
                {typeof effectiveOriginalPrice === "number"
                  ? `$${effectiveOriginalPrice.toLocaleString()}`
                  : effectiveOriginalPrice}
              </p>
            ) : null}
          </div>

          <div className="my-6 h-[1px] w-full bg-[#D1B79E]/40" />

          <p className="text-sm leading-relaxed text-[#7E7E86]">
            {product.description ||
              "Crafted with precision and premium materials, this piece offers timeless elegance and exceptional comfort for any occasion."}
          </p>

          {/* Guarded by cartLoading so this line never flashes "0 in bag"
              before the cart query has actually resolved. */}
          {!cartLoading && existingQuantity > 0 && (
            <p className="mt-4 text-[10px] tracking-wide text-[#6F7663]">
              {existingQuantity} already in your bag.
            </p>
          )}

          {/* Quantity Selector — how many to add, never disabled */}
          <div className="mt-8 flex items-center gap-6">
            <span className="text-[10px] font-medium tracking-[0.2em] text-[#432817] uppercase">Quantity</span>
            <div className="flex items-center border border-[#D1B79E] bg-white">
              <button
                type="button"
                onClick={() => setQuantity((prev) => Math.max(1, prev - 1))}
                className="px-3 py-2 text-[#432817] transition hover:bg-[#EDE6DA] disabled:opacity-30"
                disabled={quantity <= 1}
                aria-label="Decrease quantity"
              >
                <Minus size={14} />
              </button>
              <span className="w-8 text-center text-xs font-medium text-[#432817]">{quantity}</span>
              <button
                type="button"
                onClick={() => setQuantity((prev) => Math.min(99, prev + 1))}
                className="px-3 py-2 text-[#432817] transition hover:bg-[#EDE6DA] disabled:opacity-30"
                disabled={quantity >= 99}
                aria-label="Increase quantity"
              >
                <Plus size={14} />
              </button>
            </div>
          </div>

          {/* Action Buttons */}
          <div className="mt-8 flex items-center gap-4">
            <button
              type="button"
              onClick={handleAddToCart}
              disabled={isMutating}
              className={`flex flex-1 items-center justify-center gap-3 py-4 text-[10px] font-medium tracking-[0.2em] uppercase transition-all ${isMutating ? "cursor-wait bg-[#8a7a67] text-[#EDE6DA]" : "bg-[#432817] text-[#EDE6DA] hover:bg-[#5a3720]"
                }`}
            >
              {isMutating ? (
                <>
                  <span className="h-3 w-3 animate-spin rounded-full border-2 border-[#EDE6DA]/40 border-t-[#EDE6DA]" />
                  Adding...
                </>
              ) : (
                <>
                  <ShoppingBag size={16} strokeWidth={1.5} /> Add to Cart
                </>
              )}
            </button>

            <button
              type="button"
              onClick={handleToggleWishlist}
              disabled={isWishlistMutating}
              aria-label={liked ? `Remove ${product.name} from wishlist` : `Add ${product.name} to wishlist`}
              className={`flex h-[52px] w-[52px] shrink-0 items-center justify-center border transition-all disabled:opacity-60 ${liked
                ? "border-[#432817] bg-[#432817] text-[#EDE6DA]"
                : "border-[#D1B79E] text-[#432817] hover:border-[#432817]"
                }`}
            >
              <Heart size={18} strokeWidth={1.5} fill={liked ? "currentColor" : "none"} />
            </button>
          </div>

          {cartMessage && (
            <p
              className={`mt-3 flex items-center gap-1.5 text-[10px] tracking-wide ${cartMessageTone === "good" ? "text-[#6F7663]" : "text-red-600"
                }`}
            >
              {cartMessageTone === "good" && <Check size={12} />}
              {cartMessage}
            </p>
          )}
        </div>
      </div>
    </div>
  );
}
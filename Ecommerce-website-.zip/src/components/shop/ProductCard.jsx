import { Heart, ShoppingBag } from "lucide-react";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { useAuth } from "../../hooks/useAuth";
import { useQueryClient } from "@tanstack/react-query";
import { useWishlist } from "../../hooks/useWishlist";

export default function ProductCard({
  id,
  name = "Classic Fashion Item",
  price = 222,
  image,
  category,
  badge,
  isInCart = false,
  onAddToCart,
  isCartLoading = false,
  dealId = null,        // NEW
  dealName = null,       // NEW
  originalPrice = null,  // NEW
}) {
  const { user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();

  const [isAdding, setIsAdding] = useState(false);
  const [cartMessage, setCartMessage] = useState("");

  const activeUserId = user?.id || user?._id || user?.sub || user?.email;
  const queryKey = ["cart", activeUserId];

  const cartData = queryClient.getQueryData(queryKey) || { items: [] };
  const cachedItems = cartData.items || [];

  const normDeal = (v) => (v === undefined || v === null || v === "" ? "" : String(v));
  const isCachedInCart = cachedItems.some(
    (item) =>
      String(item.productId || item.product_id) === String(id) &&
      normDeal(item.dealId ?? item.deal_id) === normDeal(dealId)
  );

  const isAddedLocal = isCachedInCart || isInCart;

  const { isInWishlist, toggleWishlist, removeFromWishlist, isMutating: isWishlistMutating } =
    useWishlist(activeUserId);

  const liked = isInWishlist(id, dealId);

  const formattedPrice =
    typeof price === "number" ? `$${price.toLocaleString()}` : price;

  // Deal wale products mein original price strikethrough ke sath dikhani hai —
  // sirf tab jab originalPrice maujood ho aur discounted price se alag ho.
  const hasDiscount =
    originalPrice != null &&
    Number(originalPrice) !== Number(price);

  const formattedOriginalPrice = hasDiscount
    ? typeof originalPrice === "number"
      ? `$${originalPrice.toLocaleString()}`
      : `$${Number(originalPrice).toLocaleString()}`
    : null;

  const handleCardClick = () => {
    if (!id) return;

    // Deal se aaya hua card hai to deal ki info ProductDetail tak query
    // params ke zariye bhejte hain — wahan wahi dark pill badge aur
    // discounted price dikhane ke liye use hoti hai (bilkul isi card
    // jaisa). Deal na ho to plain product link hi chalta hai.
    if (dealName && hasDiscount) {
      const params = new URLSearchParams({
        deal: dealName,
        dealPrice: String(price),
      });
      if (dealId != null) params.set("dealId", String(dealId));
      navigate(`/product/${id}?${params.toString()}`);
      return;
    }

    navigate(`/product/${id}`);
  };

  const handleQuickAdd = async (e) => {
    e.stopPropagation();
    if (isAdding || isAddedLocal || isCartLoading) return;

    if (!activeUserId) {
      setCartMessage("Please sign in first.");
      setTimeout(() => navigate("/login"), 1000);
      return;
    }

    if (!onAddToCart) return;

    setIsAdding(true);
    setCartMessage("");

    try {
      await onAddToCart(id);
      // Cart mein add hone ke baad, agar yeh wishlist mein tha to nikal do
      if (liked) {
        await removeFromWishlist(id, dealId);
      }
    } catch (error) {
      console.error("Quick add error:", error);
      setCartMessage(error?.message || "Something went wrong.");
    } finally {
      setIsAdding(false);
    }
  };

  const handleToggleWishlist = async (e) => {
    e.stopPropagation();
    if (isWishlistMutating) return;

    if (!activeUserId) {
      navigate("/login");
      return;
    }

    // Wishlist mein hamesha original (non-discount) price jata hai —
    // agar deal se aaya hai to originalPrice use hoga, warna normal price.
    await toggleWishlist(id, {
      name,
      price: originalPrice ?? price,
      image,
      dealId,
      dealName,
    });
  };

  return (
    <article
      onClick={handleCardClick}
      className="group cursor-pointer"
    >
     <div className="relative aspect-[4/5] overflow-hidden bg-[#D1B79E]/30">
  {image ? (
    <img
      src={image}
      alt={name}
      loading="lazy"
      className="h-full w-full object-cover object-top transition-transform duration-500 ease-out group-hover:scale-[1.04]"
    />
  ) : (
    <div className="flex h-full w-full items-center justify-center bg-[#D1B79E]/30">
      <span className="text-[10px] tracking-[0.2em] text-[#7E7E86] uppercase">
        No Image
      </span>
    </div>
  )}

        {badge && (
          <div className="absolute left-3 top-3 bg-[#EDE6DA] px-3 py-1.5">
            <span className="text-[8px] font-medium tracking-[0.15em] text-[#432817] uppercase">
              {badge}
            </span>
          </div>
        )}

        <button
          type="button"
          onClick={handleToggleWishlist}
          disabled={isWishlistMutating}
          aria-label={liked ? `Remove ${name} from wishlist` : `Add ${name} to wishlist`}
          className={`absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full backdrop-blur-sm transition-all disabled:opacity-60 ${liked
            ? "bg-[#432817] text-[#EDE6DA]"
            : "bg-[#EDE6DA]/90 text-[#432817] hover:bg-[#432817] hover:text-[#EDE6DA]"
            }`}
        >
          <Heart
            size={16}
            strokeWidth={1.4}
            fill={liked ? "currentColor" : "none"}
          />
        </button>

        {/* Quick Add Button */}
        <button
          type="button"
          onClick={handleQuickAdd}
          disabled={isAdding || isAddedLocal || isCartLoading}
          aria-label={isAddedLocal ? `${name} is in cart` : `Add ${name} to cart`}
          className={`absolute bottom-3 left-3 right-3 flex items-center justify-center gap-2 py-3 text-[9px] font-medium tracking-[0.2em] uppercase transition-all duration-300 ${isAddedLocal
            ? "translate-y-0 opacity-100 cursor-not-allowed bg-[#6F7663] text-[#F7F3EC]"
            : "translate-y-3 opacity-0 pointer-events-none group-hover:translate-y-0 group-hover:opacity-100 group-hover:pointer-events-auto bg-[#EDE6DA] text-[#432817] hover:bg-[#432817] hover:text-[#EDE6DA]"
            }`}
        >
          <ShoppingBag size={13} strokeWidth={1.4} />
          <span>
            {isAdding
              ? "Adding..."
              : isAddedLocal
                ? "Added to Cart ✓"
                : cartMessage || "Quick add"}
          </span>
        </button>
      </div>

      <div className="pt-4">
        {category && (
          <p className="mb-2 text-[9px] tracking-[0.15em] text-[#7E7E86] uppercase">
            {category}
          </p>
        )}

        <div className="flex items-start justify-between gap-4">
          <h3 className="text-xs font-medium tracking-wide text-[#432817]">
            {name}
          </h3>
          <div className="shrink-0 flex flex-col items-end gap-0.5">
            <p className="text-xs font-medium text-[#432817]">{formattedPrice}</p>
            {hasDiscount && (
              <p className="text-[10px] text-[#8A8177] line-through">
                {formattedOriginalPrice}
              </p>
            )}
          </div>
        </div>
      </div>
    </article>
  );
}
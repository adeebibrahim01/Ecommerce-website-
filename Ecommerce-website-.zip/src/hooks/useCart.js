import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";

// Cart Worker Service URL
const API_BASE_URL = "https://cart-worker-service.adeebibrahim01.workers.dev";

// Stable fallback references — inline `{ items: [], ... }` defaults har render
// pe NAYA object banate hain jo infinite re-render loop ka baais banta hai.
// Module-level constant hamesha wahi ek reference rehta hai.
const EMPTY_CART = { items: [], totalCount: 0 };
const EMPTY_LOYALTY = { points: 0, settings: null };

export function useCart(userId) {
  const queryClient = useQueryClient();
  const queryKey = ["cart", userId];

  /*
  |--------------------------------------------------------------------------
  | Fetch Cart Query
  |--------------------------------------------------------------------------
  */
  const {
    data = EMPTY_CART,
    isLoading,
    refetch,
  } = useQuery({
    queryKey,
    queryFn: async () => {
      if (!userId) return EMPTY_CART;

      const response = await fetch(
        `${API_BASE_URL}/cart?userId=${encodeURIComponent(userId)}&_t=${Date.now()}`,
        {
          cache: "no-store",
        }
      );

      const contentType = response.headers.get("content-type");
      if (!contentType || !contentType.includes("application/json")) {
        throw new Error(`Server returned non-JSON response (Status: ${response.status})`);
      }

      const resData = await response.json();

      if (!response.ok || !resData.success) {
        throw new Error(resData.error || resData.message || "Failed to fetch cart.");
      }

      const items = resData.items || resData.cart || [];
      const totalQuantity = items.reduce(
        (total, item) => total + Number(item.quantity || 0),
        0
      );

      return { items, totalCount: totalQuantity };
    },
    enabled: !!userId,
    staleTime: 1000 * 60 * 5,
    refetchOnWindowFocus: false,
  });

  /*
  |--------------------------------------------------------------------------
  | Add/Update Item Mutation (Optimistic Update)
  |--------------------------------------------------------------------------
  | NOTE: `quantity` is treated as a DELTA (can be positive to add or
  | negative to decrease) - it matches the worker's SQL which does
  | `quantity = cart.quantity + excluded.quantity`. Only 0/undefined/NaN
  | falls back to 1.
  |--------------------------------------------------------------------------
  */
  const resolveDelta = (quantity) => {
    const raw = Number(quantity);
    return Number.isFinite(raw) && raw !== 0 ? raw : 1;
  };

  // "" for no-deal so a normal add and a deal add of the same product
  // never get treated as the same cart line (mirrors the backend's
  // deal_id normalization in cart-worker.js).
  const normDeal = (v) => (v === undefined || v === null || v === "" ? "" : String(v));
  const isSameLine = (item, productId, dealId) =>
    String(item.productId ?? item.product_id) === String(productId) &&
    normDeal(item.dealId ?? item.deal_id) === normDeal(dealId);

  const addToCartMutation = useMutation({
    mutationFn: async ({ productId, quantity, product }) => {
      const productName = product?.name || product?.title || `Product #${productId}`;
      const productPrice = product?.price !== undefined && product?.price !== null ? Number(product.price) : 0;
      const productImage = product?.image || product?.img || product?.thumbnail || "";

      const dealId = product?.dealId ?? null;
      const dealName = product?.dealName ?? null;
      const originalPrice =
        product?.originalPrice !== undefined && product?.originalPrice !== null
          ? Number(product.originalPrice)
          : null;

      const finalQuantity = resolveDelta(quantity);

      const payload = {
        userId,
        productId: String(productId),
        quantity: finalQuantity,
        name: productName,
        price: productPrice,
        image: productImage,
        dealId,
        dealName,
        originalPrice,
      };

      const response = await fetch(`${API_BASE_URL}/cart/add`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || "Failed to update cart");
      }
      return resData;
    },
    onMutate: async ({ productId, quantity, product }) => {
      await queryClient.cancelQueries({ queryKey });
      const previousCart = queryClient.getQueryData(queryKey);

      const productName = product?.name || product?.title || `Product #${productId}`;
      const productPrice = product?.price !== undefined && product?.price !== null ? Number(product.price) : 0;
      const productImage = product?.image || product?.img || product?.thumbnail || "";

      const dealId = product?.dealId ?? null;
      const dealName = product?.dealName ?? null;
      const originalPrice =
        product?.originalPrice !== undefined && product?.originalPrice !== null
          ? Number(product.originalPrice)
          : null;

      const delta = resolveDelta(quantity);

      queryClient.setQueryData(queryKey, (old = EMPTY_CART) => {
        const items = [...(old.items || [])];
        const existingIndex = items.findIndex((item) => isSameLine(item, productId, dealId));

        if (existingIndex > -1) {
          const newQty = Math.max(0, Number(items[existingIndex].quantity || 0) + delta);
          items[existingIndex] = { ...items[existingIndex], quantity: newQty };
        } else if (delta > 0) {
          items.push({
            productId: String(productId),
            product_id: String(productId),
            quantity: delta,
            name: productName,
            price: productPrice,
            image: productImage,
            dealId,
            dealName,
            originalPrice,
          });
        }

        const totalQuantity = items.reduce((total, item) => total + Number(item.quantity || 0), 0);
        return { items, totalCount: totalQuantity };
      });

      return { previousCart };
    },
    onError: (err, variables, context) => {
      if (context?.previousCart) {
        queryClient.setQueryData(queryKey, context.previousCart);
      }
      console.error("❌ [FRONTEND ADD ERROR] Failed to update cart:", err);
    },
    onSuccess: (serverData) => {
      const items = serverData.items || serverData.cart;
      if (items) {
        const totalQuantity = items.reduce(
          (total, item) => total + Number(item.quantity || 0),
          0
        );
        queryClient.setQueryData(queryKey, { items, totalCount: totalQuantity });
      }
      window.dispatchEvent(new Event("cart-change"));
    },
  });

  /*
  |--------------------------------------------------------------------------
  | Loyalty balance query
  |--------------------------------------------------------------------------
  */
  const {
    data: loyalty = EMPTY_LOYALTY,
    isLoading: loyaltyLoading,
    refetch: refetchLoyalty,
  } = useQuery({
    queryKey: ["loyalty", userId],
    queryFn: async () => {
      if (!userId) return EMPTY_LOYALTY;
      const response = await fetch(`${API_BASE_URL}/loyalty/balance?userId=${encodeURIComponent(userId)}`);
      const resData = await response.json();
      if (!response.ok || !resData.success) throw new Error(resData.error || "Failed to fetch loyalty balance.");
      return { points: resData.points, settings: resData.settings };
    },
    enabled: !!userId,
    staleTime: 1000 * 30,
  });

  /*
  |--------------------------------------------------------------------------
  | Remove Item Mutation
  |--------------------------------------------------------------------------
  */
  const removeFromCartMutation = useMutation({
    mutationFn: async ({ productId, dealId }) => {
      const response = await fetch(`${API_BASE_URL}/cart/remove`, {
        method: "DELETE",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ userId, productId: String(productId), dealId: dealId ?? "" }),
      });

      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || "Failed to remove item");
      }
      return resData;
    },
    onMutate: async ({ productId, dealId }) => {
      await queryClient.cancelQueries({ queryKey });
      const previousCart = queryClient.getQueryData(queryKey);

      queryClient.setQueryData(queryKey, (old = EMPTY_CART) => {
        const items = (old.items || []).filter((item) => !isSameLine(item, productId, dealId));

        const totalQuantity = items.reduce(
          (total, item) => total + Number(item.quantity || 0),
          0
        );

        return { items, totalCount: totalQuantity };
      });

      return { previousCart };
    },
    onError: (err, variables, context) => {
      if (context?.previousCart) {
        queryClient.setQueryData(queryKey, context.previousCart);
      }
      console.error("❌ [FRONTEND REMOVE ERROR] Failed to remove item:", err);
    },
    onSuccess: (serverData) => {
      const items = serverData.items || serverData.cart;
      if (items) {
        const totalQuantity = items.reduce(
          (total, item) => total + Number(item.quantity || 0),
          0
        );
        queryClient.setQueryData(queryKey, { items, totalCount: totalQuantity });
      }
      window.dispatchEvent(new Event("cart-change"));
    },
  });

  /*
  |--------------------------------------------------------------------------
  | Stripe Checkout — Stripe ke hosted page ka session banata hai
  |--------------------------------------------------------------------------
  */
  const createCheckoutSessionMutation = useMutation({
    mutationFn: async (redeemPoints = 0) => {
      const response = await fetch(`${API_BASE_URL}/create-checkout-session`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          userId,
          redeemPoints,
          successUrl: `${window.location.origin}/order-success?session_id={CHECKOUT_SESSION_ID}`,
          cancelUrl: `${window.location.origin}/cart`,
        }),
      });

      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || "Failed to start checkout");
      }
      return resData;
    },
  });

  // ---- Plain async wrapper functions (return se PEHLE define hone zaroori hain) ----

  const addToCart = async (productId, quantity = 1, product = {}) => {
    if (!userId || !productId) return false;

    try {
      await addToCartMutation.mutateAsync({ productId, quantity, product });
      return true;
    } catch {
      return false;
    }
  };

  const removeFromCart = async (productId, dealId) => {
    if (!userId || !productId) return false;
    try {
      await removeFromCartMutation.mutateAsync({ productId, dealId });
      return true;
    } catch {
      return false;
    }
  };

  // Isse call karne par user Stripe ki page par redirect ho jayega.
  // Order webhook se banega jab payment successful ho jayegi.
  const startCheckout = async (redeemPoints = 0) => {
    if (!userId) return { success: false, error: "Please log in first." };
    try {
      const result = await createCheckoutSessionMutation.mutateAsync(redeemPoints);
      window.location.href = result.url;
      return { success: true };
    } catch (error) {
      return { success: false, error: error.message };
    }
  };

  return {
    cartCount: data.totalCount,
    cartItems: data.items,
    isLoading,
    refreshCart: refetch,
    addToCart,
    removeFromCart,
    startCheckout,
    isStartingCheckout: createCheckoutSessionMutation.isPending,
    isMutating: addToCartMutation.isPending || removeFromCartMutation.isPending,
    loyalty,
    loyaltyLoading,
    refetchLoyalty,
  };
}